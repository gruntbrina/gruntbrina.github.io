// main.js

console.log(`yo`);